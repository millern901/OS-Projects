#ifndef READ_FILE_H_
#define READ_FILE_H_

char *read_file(const char *filename);

#endif /* READ_FILE_H_ */