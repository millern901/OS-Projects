#include <cstdlib>
#include <cstdio>
#include "read_file.h"

int main(int argc, char **argv) {
	// call the read file function on the filename passed in the terminal
	char *file_contents = read_file(argv[1]);

	// the file was not accessable
	if (file_contents == nullptr) {
		// print the appropriate response
		printf("Error: File Not Found\n");
	}
	// the file was accessable
	else {
		// print the files contents and free the pointer memory
		printf("%s", file_contents);
		free(file_contents);
	}
	return 0;
}
