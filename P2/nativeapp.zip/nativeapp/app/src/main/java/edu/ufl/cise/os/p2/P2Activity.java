package edu.ufl.cise.os.p2;

import android.os.Bundle;
import android.widget.TextView;
import android.app.Activity;
// additional package imports
import android.widget.Button;
import android.widget.EditText;
import android.view.View;


public class P2Activity extends Activity {
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    // initialize the GUI elements
    private EditText filenameBox;
    private Button submitButton;
    private TextView displayBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p2);

        // Set the GUI elements views
        filenameBox = (EditText) findViewById(R.id.filenameBox);
        submitButton = (Button) findViewById(R.id.submitButton);
        displayBox = (TextView) findViewById(R.id.displayBox);

        // set an on click listener for when a user make a submit for a file
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // grab filename from submit box
                String filename = filenameBox.getText().toString();
                // set the display box content to the results of the native function call
                displayBox.setText(stringFromJNI(filename));
            }
        });
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI(String filename);
}
