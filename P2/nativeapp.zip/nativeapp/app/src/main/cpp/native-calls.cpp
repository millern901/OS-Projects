#include <jni.h>
#include <string>
#include "read_file.h"

extern "C"
JNIEXPORT jstring

JNICALL
Java_edu_ufl_cise_os_p2_P2Activity_stringFromJNI(JNIEnv *env, jobject, jstring filename) {
    // we execute the same process as in our display file test in ubuntu
    // initialize a buffer calling the read file function
    // JNI call returns a pointer to a UFT-8 encoding of the passed string
    char *bufPtr = read_file(env->GetStringUTFChars(filename, 0));

    // determine if the file was not accessible and return the proper message
    // JNI call returns a new java string with its message
    if (bufPtr == nullptr) {
        return env->NewStringUTF("Error File Not Found.\n");
    }
    // if the file was accessible we sends it contents in the form of a java string
    // JNI call here was the same as before and then we free the pointer
    jstring fileContents = env->NewStringUTF(bufPtr);
    free(bufPtr);

    // return the file contents
    return fileContents;
}
