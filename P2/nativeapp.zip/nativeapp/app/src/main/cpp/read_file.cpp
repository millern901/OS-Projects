#include <cstdio>
#include <cstdlib>
#include "unistd.h"
#include "read_file.h"

char *read_file(const char *filename) {
	// check if the file is accessible
	if (access(filename, F_OK) != -1) {
		// the file is accessible, so open it as read-only
		FILE *fd = fopen(filename, "r");

		// seek to the end of the file
		fseek(fd, 0L, SEEK_END);
		// ask for the offset to determine length
		long file_length = ftell(fd);
		// seek back to the start of the file
		fseek(fd, 0L, SEEK_SET);

		// allocate a buffer big enough to store all characters plus one
		char *buffer = (char*) malloc(sizeof(char) * (file_length + 1));
		// set the end of the buffer to the null character signifying the end of the file
		buffer[file_length] = '\0';

		// read file's textual data into the character buffer
		fread(buffer, sizeof(char), file_length, fd);

		// close the file and return its contents
		fclose(fd);
		return buffer;
	}
	// the file is not accessible, so return a null pointer
	return nullptr;
}
