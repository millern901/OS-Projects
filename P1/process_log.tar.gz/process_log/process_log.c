#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <linux/kernel.h>
#include "process_log.h"

// functions to execute get, set, and message syscalls
int get_proc_log_level()
{
	return syscall(435);
}
int set_proc_log_level(int new_level)
{
	return syscall(436, new_level);
}
int proc_log_message(int level, char* message)
{
	return syscall(437, message, level);
}

// harness functions to retrieve information for get and set log level syscalls
int* retrieve_get_level_params()
{
        int *params = malloc(2);
        params[0] = 435;
        params[1] = 0;
        return params;
}
int*  retrieve_set_level_params(int new_level)
{
	int* params = malloc(3);
	params[0] = 436;
	params[1] = 1;
	params[2] = new_level;
	return params;
}

// harness functions to interpret results from get, set, and message log level syscalls
int interpret_get_level_result(int ret_value)
{
         return ret_value;
}
int interpret_set_level_result(int ret_value)
{
         return ret_value;
}
int interpret_log_message_result(int ret_value)
{
         return ret_value;
}
